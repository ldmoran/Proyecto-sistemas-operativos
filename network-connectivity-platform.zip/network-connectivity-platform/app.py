from flask import Flask, render_template, request, jsonify
import subprocess
from datetime import datetime
from database.mongo import collection
from bson import ObjectId
import re
import socket
import platform

app = Flask(__name__)

# Función auxiliar para validar IP/dominio
def validar_objetivo(target):
    """Valida que el objetivo sea una IP o dominio válido"""
    patron_ip = r'^(\d{1,3}\.){3}\d{1,3}$'
    patron_dominio = r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    
    if re.match(patron_ip, target):
        octetos = target.split('.')
        return all(0 <= int(octeto) <= 255 for octeto in octetos)
    
    return bool(re.match(patron_dominio, target))

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/ping", methods=["POST"])
def ping():
    try:
        data_request = request.get_json()
        if not data_request or "target" not in data_request or data_request["target"].strip() == "":
            return jsonify({
                "error": "Debe ingresar una dirección IP o dominio válido"
            }), 400

        target = data_request["target"].strip()
        
        if not validar_objetivo(target):
            return jsonify({
                "error": "El formato de IP o dominio no es válido"
            }), 400

        intentos = 5
        exitos = 0
        tiempos_respuesta = []

        for _ in range(intentos):
            result = subprocess.run(
                ["ping", "-n", "1", target],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                exitos += 1
                try:
                    if "tiempo=" in result.stdout or "time=" in result.stdout:
                        tiempo_str = result.stdout.split("tiempo=")[-1] if "tiempo=" in result.stdout else result.stdout.split("time=")[-1]
                        tiempo = int(tiempo_str.split("ms")[0])
                        tiempos_respuesta.append(tiempo)
                except:
                    pass

        porcentaje = (exitos / intentos) * 100
        tiempo_promedio = sum(tiempos_respuesta) / len(tiempos_respuesta) if tiempos_respuesta else None

        if porcentaje == 100:
            estado = "Conectividad estable"
        elif porcentaje >= 50:
            estado = "Conectividad inestable"
        else:
            estado = "Sin conectividad"

        data = {
            "tipo_prueba": "ping_multiple",
            "objetivo": target,
            "intentos": intentos,
            "respuestas": exitos,
            "porcentaje_exito": porcentaje,
            "estado": estado,
            "tiempo_promedio_ms": tiempo_promedio,
            "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        result = collection.insert_one(data)
        data["_id"] = str(result.inserted_id)

        return jsonify(data)

    except subprocess.TimeoutExpired:
        return jsonify({
            "error": "Tiempo de espera agotado",
            "detalle": "El objetivo no responde"
        }), 408
    except Exception as e:
        print("ERROR EN /ping:", e)
        return jsonify({
            "error": "Error interno del servidor",
            "detalle": str(e)
        }), 500

@app.route("/traceroute", methods=["POST"])
def traceroute():
    """Realiza un traceroute al objetivo especificado"""
    try:
        data_request = request.get_json()
        if not data_request or "target" not in data_request or data_request["target"].strip() == "":
            return jsonify({
                "error": "Debe ingresar una dirección IP o dominio válido"
            }), 400

        target = data_request["target"].strip()
        
        if not validar_objetivo(target):
            return jsonify({
                "error": "El formato de IP o dominio no es válido"
            }), 400

        # Determinar comando según el sistema operativo
        sistema = platform.system().lower()
        if sistema == "windows":
            cmd = ["tracert", "-d", "-h", "15", target]
        else:
            cmd = ["traceroute", "-m", "15", "-n", target]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60
        )

        # Parsear salida
        saltos = []
        lineas = result.stdout.split('\n')
        
        for linea in lineas:
            linea = linea.strip()
            if not linea:
                continue
            
            # Buscar líneas con saltos (contienen números de salto)
            if sistema == "windows":
                # Formato Windows: "  1    <1 ms    <1 ms    <1 ms  192.168.1.1"
                match = re.match(r'\s*(\d+)\s+(<?\d+\s*ms|\*)\s+(<?\d+\s*ms|\*)\s+(<?\d+\s*ms|\*)\s+([\d\.]+|\*)', linea)
                if match:
                    salto_num = match.group(1)
                    tiempo1 = match.group(2).replace('ms', '').strip()
                    ip = match.group(5)
                    saltos.append({
                        "salto": int(salto_num),
                        "ip": ip if ip != '*' else "Sin respuesta",
                        "tiempo": tiempo1 if tiempo1 != '*' else "N/A"
                    })
            else:
                # Formato Unix/Linux
                match = re.match(r'\s*(\d+)\s+([\d\.]+|\*)\s+([\d\.]+)\s*ms', linea)
                if match:
                    saltos.append({
                        "salto": int(match.group(1)),
                        "ip": match.group(2) if match.group(2) != '*' else "Sin respuesta",
                        "tiempo": match.group(3) + " ms"
                    })

        exito = result.returncode == 0 and len(saltos) > 0

        data = {
            "tipo_prueba": "traceroute",
            "objetivo": target,
            "saltos": saltos,
            "total_saltos": len(saltos),
            "exito": exito,
            "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        # Guardar en MongoDB
        result_db = collection.insert_one(data)
        data["_id"] = str(result_db.inserted_id)

        return jsonify(data)

    except subprocess.TimeoutExpired:
        return jsonify({
            "error": "Tiempo de espera agotado para traceroute"
        }), 408
    except Exception as e:
        print("ERROR EN /traceroute:", e)
        return jsonify({
            "error": "Error al realizar traceroute",
            "detalle": str(e)
        }), 500

@app.route("/dns", methods=["POST"])
def dns_lookup():
    """Realiza pruebas de resolución DNS"""
    try:
        data_request = request.get_json()
        if not data_request or "target" not in data_request or data_request["target"].strip() == "":
            return jsonify({
                "error": "Debe ingresar un dominio válido"
            }), 400

        target = data_request["target"].strip()
        
        resultados = {}
        errores = []

        # Resolución A (IPv4)
        try:
            ip_info = socket.getaddrinfo(target, None, socket.AF_INET)
            ips_v4 = list(set([info[4][0] for info in ip_info]))
            resultados["ipv4"] = ips_v4
        except socket.gaierror as e:
            errores.append(f"IPv4: {str(e)}")
            resultados["ipv4"] = []

        # Resolución AAAA (IPv6)
        try:
            ip_info_v6 = socket.getaddrinfo(target, None, socket.AF_INET6)
            ips_v6 = list(set([info[4][0] for info in ip_info_v6]))
            resultados["ipv6"] = ips_v6
        except socket.gaierror:
            resultados["ipv6"] = []

        # Resolución inversa (si hay IPv4)
        if resultados["ipv4"]:
            try:
                hostname = socket.gethostbyaddr(resultados["ipv4"][0])
                resultados["hostname_inverso"] = hostname[0]
            except:
                resultados["hostname_inverso"] = "No disponible"

        # Usar nslookup para más información
        try:
            ns_result = subprocess.run(
                ["nslookup", target],
                capture_output=True,
                text=True,
                timeout=10
            )
            resultados["nslookup_raw"] = ns_result.stdout
            
            # Extraer servidores DNS
            for linea in ns_result.stdout.split('\n'):
                if "Server:" in linea or "Servidor:" in linea:
                    servidor = linea.split(':')[-1].strip()
                    resultados["servidor_dns"] = servidor
                    break
        except:
            resultados["nslookup_raw"] = "No disponible"

        exito = len(resultados["ipv4"]) > 0 or len(resultados["ipv6"]) > 0

        data = {
            "tipo_prueba": "dns_lookup",
            "objetivo": target,
            "resultados": resultados,
            "errores": errores,
            "exito": exito,
            "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        # Guardar en MongoDB
        result_db = collection.insert_one(data)
        data["_id"] = str(result_db.inserted_id)

        return jsonify(data)

    except Exception as e:
        print("ERROR EN /dns:", e)
        return jsonify({
            "error": "Error al realizar prueba DNS",
            "detalle": str(e)
        }), 500

@app.route("/historial", methods=["GET"])
def historial():
    try:
        limite = request.args.get('limite', 10, type=int)
        pagina = request.args.get('pagina', 1, type=int)
        
        skip = (pagina - 1) * limite
        
        registros = list(
            collection.find().sort("fecha", -1).skip(skip).limit(limite)
        )
        for r in registros:
            r["_id"] = str(r["_id"])

        total_registros = collection.count_documents({})
        return jsonify({
            "registros": registros,
            "total": total_registros,
            "pagina": pagina,
            "limite": limite
        })
    except Exception as e:
        print("ERROR EN /historial:", e)
        return jsonify({
            "error": "No se pudo obtener el historial",
            "detalle": str(e)
        }), 500

@app.route("/resumen", methods=["GET"])
def resumen():
    registros = list(collection.find().sort("fecha", -1))
    if not registros:
        return jsonify({
            "total_pruebas": 0,
            "promedio_exito": 0,
            "ultimo_estado": "Sin datos",
            "estado_general": "Sin información",
            "pruebas_hoy": 0
        })

    total = 0
    contador = 0
    pruebas_hoy = 0
    fecha_hoy = datetime.now().strftime("%Y-%m-%d")

    for r in registros:
        if "porcentaje_exito" in r:
            total += r["porcentaje_exito"]
            contador += 1
        
        if r.get("fecha", "").startswith(fecha_hoy):
            pruebas_hoy += 1

    promedio = round(total / contador, 2) if contador > 0 else 0
    ultimo_estado = registros[0].get("estado", "No disponible")

    if promedio >= 80:
        estado_general = "Conectividad buena"
    elif promedio >= 50:
        estado_general = "Conectividad regular"
    else:
        estado_general = "Conectividad mala"

    return jsonify({
        "total_pruebas": len(registros),
        "promedio_exito": promedio,
        "ultimo_estado": ultimo_estado,
        "estado_general": estado_general,
        "pruebas_hoy": pruebas_hoy
    })

@app.route("/eliminar/<id_prueba>", methods=["DELETE"])
def eliminar_prueba(id_prueba):
    try:
        resultado = collection.delete_one({"_id": ObjectId(id_prueba)})
        if resultado.deleted_count == 0:
            return jsonify({"error": "Prueba no encontrada"}), 404
        return jsonify({"mensaje": "Prueba eliminada correctamente"})
    except Exception as e:
        return jsonify({
            "error": "Error al eliminar la prueba",
            "detalle": str(e)
        }), 500

@app.route("/prueba/<id_prueba>", methods=["PUT"])
def actualizar_prueba(id_prueba):
    try:
        data_request = request.get_json()
        if not data_request or "observacion" not in data_request:
            return jsonify({
                "error": "Debe enviar una observación"
            }), 400

        nueva_observacion = data_request["observacion"]
        resultado = collection.update_one(
            {"_id": ObjectId(id_prueba)},
            {"$set": {"observacion": nueva_observacion}}
        )

        if resultado.matched_count == 0:
            return jsonify({
                "error": "Prueba no encontrada"
            }), 404

        return jsonify({
            "mensaje": "Prueba actualizada correctamente"
        })
    except Exception as e:
        print("ERROR EN UPDATE:", e)
        return jsonify({
            "error": "Error al actualizar la prueba",
            "detalle": str(e)
        }), 500

@app.route("/exportar", methods=["GET"])
def exportar_datos():
    """Endpoint para exportar datos en formato JSON"""
    try:
        registros = list(collection.find().sort("fecha", -1))
        
        for r in registros:
            r["_id"] = str(r["_id"])
        
        return jsonify({
            "total": len(registros),
            "fecha_exportacion": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "datos": registros
        })
    
    except Exception as e:
        return jsonify({
            "error": "Error al exportar datos",
            "detalle": str(e)
        }), 500

@app.route("/estadisticas", methods=["GET"])
def estadisticas():
    """Endpoint para estadísticas avanzadas"""
    try:
        registros = list(collection.find())
        
        if not registros:
            return jsonify({"error": "No hay datos disponibles"}), 404
        
        objetivos_unicos = set(r.get("objetivo") for r in registros if "objetivo" in r)
        total_intentos = sum(r.get("intentos", 0) for r in registros)
        total_exitos = sum(r.get("respuestas", 0) for r in registros)
        
        return jsonify({
            "objetivos_monitoreados": len(objetivos_unicos),
            "total_intentos": total_intentos,
            "total_exitos": total_exitos,
            "tasa_exito_global": round((total_exitos / total_intentos * 100), 2) if total_intentos > 0 else 0
        })
    
    except Exception as e:
        return jsonify({
            "error": "Error al calcular estadísticas",
            "detalle": str(e)
        }), 500

if __name__ == "__main__":
    app.run(debug=True)