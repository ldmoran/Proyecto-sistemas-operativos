from database.mongo import collection
from datetime import datetime

test_data = {
    "tipo_prueba": "test_conexion",
    "mensaje": "MongoDB conectado correctamente",
    "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
}

collection.insert_one(test_data)

print("Datos insertados correctamente en MongoDB")
